<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_subject']  = '您已从 %s 发送了一张礼品券';
$_['text_greeting'] = '恭喜，您收到了一张价值 %s 的礼品券';
$_['text_from']     = '%s 将本礼品券送给您';
$_['text_message']  = '附加信息';
$_['text_redeem']   = '如果想使用本礼品券，请记录下礼品券代码（本礼品券代码为 <b>%s</b>），然后点击如下链接点击您想购买的商品。您可以在账单结算前在购物车页面使用本礼品券。';
$_['text_footer']   = '如有任何问题，请回复本邮件。';
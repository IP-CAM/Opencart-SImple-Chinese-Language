<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text
$_['text_feed']        = '输出共享';
$_['text_success']     = '成功: 已修改 Google Sitemap 输出共享！';
$_['text_edit']        = '编辑 Google Sitemap';

// Entry
$_['entry_status']     = '状态';
$_['entry_data_feed']  = '数据输出共享 Url 链接';

// Error
$_['error_permission'] = '警告: 无权限修改 Google Sitemap 输出共享！';
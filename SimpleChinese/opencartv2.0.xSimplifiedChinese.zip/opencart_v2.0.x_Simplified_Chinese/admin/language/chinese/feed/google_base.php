<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading
$_['heading_title']    = 'Google Base';

// Text
$_['text_feed']        = '输出共享';
$_['text_success']     = '成功: 已修改 Google Base 输出共享！';
$_['text_list']        = 'Layout List';
$_['text_edit']        = '编辑 Google Base';

// Entry
$_['entry_status']     = '状态';
$_['entry_data_feed']  = '数据输出共享 Url 链接';

// Error
$_['error_permission'] = '警告: 无权限修改 Google Base 输出共享！';
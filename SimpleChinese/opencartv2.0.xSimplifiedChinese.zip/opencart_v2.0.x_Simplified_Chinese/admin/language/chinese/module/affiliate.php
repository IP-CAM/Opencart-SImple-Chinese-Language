<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading
$_['heading_title']    = '加盟会员';

$_['text_module']      = '模组';
$_['text_success']     = '成功: 已修改加盟会员模组！';
$_['text_edit']        = '编辑加盟会员模组';

// Entry
$_['entry_status']     = '状态';

// Error
$_['error_permission'] = '警告: 您无权限修改加盟会员模组！';
<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading
$_['heading_title']     = '在线会员报告';

// Text
$_['text_list']         = '在线会员列表';
$_['text_guest']        = '访客';

// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = '会员';
$_['column_url']        = '最后访问页面';
$_['column_referer']    = '来自重定向';
$_['column_date_added'] = '最后点击';
$_['column_action']     = '操作';

// Entry
$_['entry_ip']          = 'IP';
$_['entry_customer']    = '会员';
<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading
$_['heading_title']         = '会员奖励积分报告';

// Text
$_['text_list']             = '会员奖励积分列表';

// Column
$_['column_customer']       = '会员姓名';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = '会员等级';
$_['column_status']         = '状态';
$_['column_points']         = '奖励积分';
$_['column_orders']         = '订单数量';
$_['column_total']          = '总计';
$_['column_action']         = '操作';

// Entry
$_['entry_date_start']      = '开始日期';
$_['entry_date_end']        = '结束日期';
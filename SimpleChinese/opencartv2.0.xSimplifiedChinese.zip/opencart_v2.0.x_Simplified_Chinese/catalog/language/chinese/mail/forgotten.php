<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_subject']  = '%s - 会员新密码';
$_['text_greeting'] = '%s 生成新密码';
$_['text_password'] = '您的新密码为:';

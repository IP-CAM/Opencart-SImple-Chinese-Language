<?php
/**
 * $Author: http://www.opencartchina.com 
**/
$_['text_total'] = '总计';
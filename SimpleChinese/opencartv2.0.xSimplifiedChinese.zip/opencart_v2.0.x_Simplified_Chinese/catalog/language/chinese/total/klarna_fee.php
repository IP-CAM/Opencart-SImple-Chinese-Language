<?php
/**
 * $Author: http://www.opencartchina.com 
**/
$_['text_klarna_fee'] = 'Klarna 费用';
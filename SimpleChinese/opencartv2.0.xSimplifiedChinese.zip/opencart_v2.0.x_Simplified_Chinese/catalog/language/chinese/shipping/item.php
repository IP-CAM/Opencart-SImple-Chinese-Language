<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_title']       = '按每件计运费';
$_['text_description'] = '按每件计运费率';
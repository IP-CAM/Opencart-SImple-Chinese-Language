<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_title']    = '澳大利亚邮政';
$_['text_express']  = '特快';
$_['text_standard'] = '标准';
$_['text_eta']      = '天';
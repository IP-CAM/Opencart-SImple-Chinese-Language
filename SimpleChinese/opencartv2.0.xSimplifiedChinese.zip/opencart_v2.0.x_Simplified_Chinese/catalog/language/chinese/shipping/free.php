<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_title']       = '免运费';
$_['text_description'] = '免运费';
<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_search'] = '搜索';
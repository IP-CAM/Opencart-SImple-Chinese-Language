<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_home']          = '首页';
$_['text_wishlist']      = '收藏 (%s)';
$_['text_shopping_cart'] = '购物车';
$_['text_category']      = '分类';
$_['text_account']       = '会员账户';
$_['text_register']      = '注册';
$_['text_login']         = '登录';
$_['text_order']         = '历史订单';
$_['text_transaction']   = '账户余额';
$_['text_download']      = '下载文件';
$_['text_logout']        = '退出登录';
$_['text_checkout']      = '去结账';
$_['text_search']        = '搜索';
$_['text_all']           = '全部';
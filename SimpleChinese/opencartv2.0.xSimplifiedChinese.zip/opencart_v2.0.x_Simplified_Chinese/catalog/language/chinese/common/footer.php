<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_information']  = '信息文章';
$_['text_service']      = '会员服务';
$_['text_extra']        = '其他';
$_['text_contact']      = '联系我们';
$_['text_return']       = '退换服务';
$_['text_sitemap']      = '网站地图';
$_['text_manufacturer'] = '品牌专区';
$_['text_voucher']      = '礼品券';
$_['text_affiliate']    = '加盟会员';
$_['text_special']      = '优惠商品';
$_['text_account']      = '会员中心';
$_['text_order']        = '历史订单';
$_['text_wishlist']     = '收藏列表';
$_['text_newsletter']   = '订阅咨询';
$_['text_powered']      = '技术支持 <a href="http://www.opencartchina.com">OpenCart中国网站</a><br /> %s &copy; %s';



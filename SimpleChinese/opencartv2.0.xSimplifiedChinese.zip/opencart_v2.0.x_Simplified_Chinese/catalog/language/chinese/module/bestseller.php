<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading
$_['heading_title'] = '畅销商品';

// Text
$_['text_tax']      = '附加税:';
<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Text
$_['text_success']       = '已修改会员';

// Error
$_['error_permission']   = '警告: 无权限访问 API 接口！';
$_['error_firstname']    = '名称必须为 1 - 32字符！';
$_['error_lastname']     = '姓氏必须为 1 - 32字符！';
$_['error_email']        = 'E-Mail 地址无效！';
$_['error_telephone']    = '电话必须为 3 - 32字符！';
$_['error_custom_field'] = '%s 必须！';
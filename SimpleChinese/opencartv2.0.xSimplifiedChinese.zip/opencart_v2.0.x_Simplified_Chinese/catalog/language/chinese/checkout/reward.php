<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading
$_['heading_title'] = '使用奖励积分 (可用奖励积分 %s)';

// Text
$_['text_success']  = '成功: 已使用奖励积分！';

// Entry
$_['entry_reward']  = '可使用奖励积分 (最大 %s)';

// Error
$_['error_reward']  = '警告: 请输入可用奖励积分数额！';
$_['error_points']  = '警告: 您没有 %s 奖励积分！';
$_['error_maximum'] = '警告: 可使用的最大奖励积分为 %s！';
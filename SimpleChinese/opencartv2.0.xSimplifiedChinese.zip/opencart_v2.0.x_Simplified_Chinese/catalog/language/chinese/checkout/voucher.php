<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading
$_['heading_title'] = '使用礼品券';

// Text
$_['text_success']  = '成功: 已使用礼品券！';

// Entry
$_['entry_voucher'] = '此处输入礼品券代码';

// Error
$_['error_voucher'] = '警告: 礼品券无效或金额已用完！';
$_['error_empty']   = '警告: 请输入礼品券代码！';
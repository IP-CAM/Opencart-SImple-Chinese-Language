<?php
/**
 * $Author: http://www.opencartchina.com 
**/
// Heading
$_['heading_title']    = '网站地图';

// Text
$_['text_special']     = '优惠商品';
$_['text_account']     = '会员账户';
$_['text_edit']        = '编辑账户';
$_['text_password']    = '密码';
$_['text_address']     = '地址簿';
$_['text_history']     = '历史订单';
$_['text_download']    = '下载文件';
$_['text_cart']        = '购物车';
$_['text_checkout']    = '结账';
$_['text_search']      = '搜索';
$_['text_information'] = '信息文章';
$_['text_contact']     = '联系我们';